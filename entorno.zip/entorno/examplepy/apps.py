from django.apps import AppConfig


class ExamplepyConfig(AppConfig):
    name = 'examplepy'
