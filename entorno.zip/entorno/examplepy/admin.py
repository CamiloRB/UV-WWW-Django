from django.contrib import admin
from .models import Entrada

admin.site.register(Entrada)

# Register your models here.
